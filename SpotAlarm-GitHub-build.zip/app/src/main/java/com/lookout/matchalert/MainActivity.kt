package com.lookout.matchalert

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var alarmButton: Button
    private lateinit var sensitivityBar: SeekBar
    private lateinit var cameraExecutor: ExecutorService
    private var referenceVector: DoubleArray? = null
    private var scanning = false
    private var lastAlertAt = 0L
    private var tone: ToneGenerator? = null
    private var alarmOn = false
    private var lastAnalysisAt = 0L

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) loadReference(uri)
    }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else statusText.text = "Camera permission is required. Enable it in Settings."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        alarmButton = findViewById(R.id.alarmButton)
        sensitivityBar = findViewById(R.id.sensitivityBar)
        cameraExecutor = Executors.newSingleThreadExecutor()

        findViewById<Button>(R.id.chooseButton).setOnClickListener { imagePicker.launch("image/*") }
        startButton.setOnClickListener {
            if (referenceVector == null) { statusText.text = "Choose a reference picture first."; return@setOnClickListener }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
            else cameraPermission.launch(Manifest.permission.CAMERA)
        }
        stopButton.setOnClickListener { stopCamera() }
        alarmButton.setOnClickListener { stopAlarm() }
    }

    private fun loadReference(uri: Uri) {
        try {
            val bitmap = android.provider.MediaStore.Images.Media.getBitmap(contentResolver, uri)
            findViewById<ImageView>(R.id.referenceImage).setImageBitmap(bitmap)
            referenceVector = vectorFromBitmap(bitmap)
            statusText.text = "Reference picture loaded. Start scanning when ready."
        } catch (_: Exception) { statusText.text = "Could not open this picture. Try another image." }
    }

    private fun startCamera() {
        if (scanning) return
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image -> analyze(image) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                scanning = true
                startButton.isEnabled = false
                stopButton.isEnabled = true
                statusText.text = "Camera active — scanning for a visual match…"
            } catch (_: Exception) { statusText.text = "Could not start camera. Close other camera apps and retry." }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(image: ImageProxy) {
        try {
            if (!scanning || referenceVector == null) return
            val now = System.currentTimeMillis()
            if (now - lastAnalysisAt < 500) return
            lastAnalysisAt = now
            val plane = image.planes[0]
            val buffer = plane.buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            val w = image.width; val h = image.height
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(w * h)
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            for (y in 0 until h) for (x in 0 until w) {
                val i = y * rowStride + x * pixelStride
                if (i + 3 < bytes.size) {
                    val r = bytes[i].toInt() and 255; val g = bytes[i+1].toInt() and 255; val b = bytes[i+2].toInt() and 255
                    pixels[y*w+x] = Color.rgb(r,g,b)
                }
            }
            bmp.setPixels(pixels, 0, w, 0, 0, w, h)
            val score = similarity(referenceVector!!, vectorFromBitmap(bmp))
            val threshold = 0.50 + (sensitivityBar.progress / 100.0)
            if (score >= threshold && now - lastAlertAt > 12000) {
                lastAlertAt = now
                runOnUiThread { triggerAlarm("Possible visual match detected (${(score*100).toInt()}%).") }
            }
        } catch (_: Exception) {
            // Ignore a single malformed camera frame; the next frame will be analyzed.
        } finally { image.close() }
    }

    private fun vectorFromBitmap(source: Bitmap): DoubleArray {
        val side = 32
        val scale = max(side.toFloat()/source.width, side.toFloat()/source.height)
        val scaled = Bitmap.createScaledBitmap(source, (source.width*scale).toInt(), (source.height*scale).toInt(), true)
        val left = max(0, (scaled.width-side)/2); val top = max(0, (scaled.height-side)/2)
        val crop = Bitmap.createBitmap(scaled, left, top, side, side)
        val px = IntArray(side*side); crop.getPixels(px,0,side,0,0,side,side)
        val values = DoubleArray(px.size) { i ->
            val c = px[i]; (0.299*Color.red(c)+0.587*Color.green(c)+0.114*Color.blue(c))/255.0
        }
        val mean = values.average()
        val variance = values.map { (it-mean)*(it-mean) }.average()
        val sd = sqrt(variance).takeIf { it > 1e-6 } ?: 1.0
        return DoubleArray(values.size) { (values[it]-mean)/sd }
    }

    private fun similarity(a: DoubleArray, b: DoubleArray): Double {
        var dot=0.0; var aa=0.0; var bb=0.0
        for (i in a.indices) { dot+=a[i]*b[i]; aa+=a[i]*a[i]; bb+=b[i]*b[i] }
        return ((dot/(sqrt(aa*bb).takeIf { it>1e-9 }!!)+1.0)/2.0).coerceIn(0.0,1.0)
    }

    private fun triggerAlarm(message: String) {
        statusText.text = message
        alarmOn = true
        alarmButton.isEnabled = true
        try {
            tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            val handler = android.os.Handler(mainLooper)
            val endAt = System.currentTimeMillis() + 15000
            val beep = object : Runnable {
                override fun run() {
                    if (!alarmOn || System.currentTimeMillis() > endAt) { stopAlarm(); return }
                    tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 450)
                    handler.postDelayed(this, 700)
                }
            }
            handler.post(beep)
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator else getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (android.os.Build.VERSION.SDK_INT >= 26) { vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0,350,200,350),0)) } else { @Suppress("DEPRECATION") vibrator.vibrate(longArrayOf(0,350,200,350),0) }
        } catch (_: Exception) { statusText.text = "$message Tap Stop alarm if sound is active." }
    }

    private fun stopAlarm() {
        alarmOn = false
        tone?.stopTone(); tone?.release(); tone = null
        try {
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator else getSystemService(VIBRATOR_SERVICE) as Vibrator
            vibrator.cancel()
        } catch (_: Exception) {}
        alarmButton.isEnabled = false
        if (scanning) statusText.text = "Scanning continues…"
    }

    private fun stopCamera() {
        scanning = false
        ProcessCameraProvider.getInstance(this).get().unbindAll()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        stopAlarm()
        statusText.text = "Camera stopped."
    }

    override fun onDestroy() {
        scanning = false
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) {}
        stopAlarm()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
