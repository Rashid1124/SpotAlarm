# SpotAlarm — Android app project

This ZIP contains a native Android (Kotlin + CameraX) prototype. It is source code, not an APK.

## Build the APK online using GitHub (no Android Studio needed)

1. Create a GitHub repository named `SpotAlarm`.
2. Upload this ZIP file itself (`SpotAlarm-GitHub-build.zip`) to the repository root. Do not extract it first.
3. In the repository, choose **Add file → Create new file**. Name the file exactly `.github/workflows/build.yml`.
4. Paste the workflow contents from the separate `SpotAlarm-build.yml` file supplied with this project, then commit it to the `main` branch.
5. Open the repository's **Actions** tab. If prompted, enable workflows.
6. Open **Build SpotAlarm APK** and tap **Run workflow** (or wait for the first push-triggered run).
7. When the run finishes successfully, open it and scroll to **Artifacts**. Download `SpotAlarm-debug-apk`.
8. Extract that downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install. If Android asks, allow your browser or Files app to install unknown apps.

## App use

1. Open SpotAlarm and choose a reference picture from Gallery.
2. Tap **Start scanning** and grant camera permission.
3. Keep the app open and screen awake while scanning.
4. Tap **Stop alarm** to silence a match alert, or **Stop** to stop the camera.

## Limitations

- This prototype uses a simple normalized grayscale image similarity comparison. It is not a trained AI recognition model and may miss the target when angle, scale, lighting, or background changes. It may also produce false positives.
- It scans the camera's current full frame; a target filling a reasonable part of the view works best.
- Scanning is foreground-only. Keep the app open and screen awake; detection is not guaranteed when the app is backgrounded or the phone is locked.
- The selected image and camera frames are processed locally by the app.

## Technical

- App label: SpotAlarm
- Package: `com.lookout.matchalert`
- Minimum Android: 8.0 (API 26)
- CameraX 1.4.2; compile/target SDK 35
